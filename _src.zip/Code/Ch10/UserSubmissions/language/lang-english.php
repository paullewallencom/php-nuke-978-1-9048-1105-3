<?php

define("_USERSUBMISSIONSANDAMENDMENTS", "User Submissions and Amendments");

define("_SUBMITNEWITEM", "Submit a new Item");
define("_CHOOSETYPE", "Choose the type of content to add");
define("_SUBMITNEWENCYCLOENTRY", "Submit a new Encyclopedia entry");
define("_YOUNEEDTOBEAUSER", "You need to be a registered user to submit or edit new items of content");



define("_EDITEXISTINGITEM", "Edit an existing item");


define("_ADDENYCLOENTRY", "Add a New Encyclopedia Entry");

define("_THANKYOUSUBMISSION", "Thank you for your submission.");
define("_THANKSTEXT","We will check your submission in the next few hours, if it is interesting, and accurate we will publish it soon.");
define("_ADDMOREITEMS", "Add More Items");


define("_WEWILLLOOKATITSOON", "We will look at it soon!");
define("_YOUNEEDTOBEAUSER", "You need to be a registered user to submit or edit new items of content");

?>