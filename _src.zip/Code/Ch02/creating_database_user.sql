GRANT ALL PRIVILEGES ON nuke.* TO nuker@localhost 
                     IDENTIFIED BY 'nukepassword' 
                     WITH GRANT OPTION
